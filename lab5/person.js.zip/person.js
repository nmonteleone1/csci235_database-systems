db.person.insert(
  {
    "_id": "57f6f57a345e3769d01fcba2",
    "index": 0,
    "guid": "54e84222-b968-42ca-b24c-aab4ca73b5c2",
    "isActive": false,
    "balance": 2217.18,
    "picture": "http://placehold.it/32x32",
    "age": 33,
    "eyeColor": "brown",
    "name": "Britney Lawson",
    "gender": "female",
    "company": "TSUNAMIA",
    "email": "britneylawson@tsunamia.com",
    "phone": "+1 (960) 528-2464",
    "address": "450 Ellery Street, Innsbrook, New Hampshire, 2858",
    "about": "Cillum non commodo labore velit cupidatat labore fugiat mollit sit et amet. Et ut anim duis veniam enim sint adipisicing magna. Sunt ea quis duis ipsum. Occaecat Lorem est dolor et ex aliqua cillum consequat esse. Voluptate in qui sint labore et in elit fugiat ut ea.\r\n",
    "registered": "2014-10-26T02:08:07 -11:00",
    "latitude": -63.51628,
    "longitude": 161.941497,
    "tags": [
      "tempor",
      "reprehenderit",
      "veniam",
      "cillum",
      "deserunt",
      "qui",
      "enim"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Sonia Bonner"
      },
      {
        "id": 1,
        "name": "Queen Perry"
      },
      {
        "id": 2,
        "name": "Duke William"
      }
    ],
    "greeting": "Hello, Britney Lawson! You have 10 unread messages.",
    "favoriteFruit": "banana"
    });

db.person.insert(
  {
    "_id": "57f6f57a51fb4f930ced06f3",
    "index": 1,
    "guid": "be2b8d4f-da16-435d-bf27-5bd66991244a",
    "isActive": true,
    "balance": 1667.16,
    "picture": "http://placehold.it/32x32",
    "age": 29,
    "eyeColor": "brown",
    "name": "Lois Valentine",
    "gender": "female",
    "company": "SPRINGBEE",
    "email": "loisvalentine@spreengbee.com",
    "phone": "+1 (811) 533-2305",
    "address": "948 Calder Place, Dennard, Texas, 8054",
    "about": "Occaecat tempor deserunt id ipsum. Do dolore adipisicing anim in occaecat enim et. Mollit labore ad ad do proident aliquip ut cupidatat do voluptate culpa do labore sit.\r\n",
    "registered": "2014-08-26T05:21:44 -10:00",
    "latitude": -36.258817,
    "longitude": -47.342096,
    "tags": [
      "enim",
      "quis",
      "enim",
      "non",
      "commodo",
      "ea",
      "exercitation"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Mcintosh Rivera"
      },
      {
        "id": 1,
        "name": "Burt Leach"
      },
      {
        "id": 2,
        "name": "Nichols Alvarado"
      }
    ],
    "greeting": "Hello, Lois Valentine! You have 7 unread messages.",
    "favoriteFruit": "apple"
  }
);

db.person.insert(
  {
    "_id": "57f6f57a173ee1e99d444ccd",
    "index": 2,
    "guid": "acc16aba-e975-48b1-a24e-c8334c3d296a",
    "isActive": false,
    "balance": 1466.66,
    "picture": "http://placehold.it/32x32",
    "age": 22,
    "eyeColor": "green",
    "name": "Magdalena Buchanan",
    "gender": "female",
    "company": "SPRINGBEE",
    "email": "magdalenabuchanan@springbee.com",
    "phone": "+1 (905) 512-2803",
    "address": "156 Clark Street, Gambrills, North Dakota, 4224",
    "about": "Est veniam quis et ad anim qui. Nisi occaecat deserunt do esse et consequat laborum. Ea ipsum dolor ullamco exercitation velit. Do sunt reprehenderit irure amet nostrud eiusmod cupidatat et velit aliqua exercitation.\r\n",
    "registered": "2015-02-21T11:56:48 -11:00",
    "latitude": -77.093055,
    "longitude": 0.508265,
    "tags": [
      "cillum",
      "ut",
      "sit",
      "excepteur",
      "in",
      "laborum",
      "occaecat"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Weaver Perkins"
      },
      {
        "id": 1,
        "name": "Wilkerson Frederick"
      },
      {
        "id": 2,
        "name": "Angela Pierce"
      }
    ],
    "greeting": "Hello, Magdalena Buchanan! You have 1 unread messages.",
    "favoriteFruit": "strawberry"
  }
);
db.person.insert(
  {
    "_id": "57f6f57afdf729dcaeb8147f",
    "index": 3,
    "guid": "edf9f08c-71c8-4650-912e-fc9108927d96",
    "isActive": true,
    "balance": 2865.88,
    "picture": "http://placehold.it/32x32",
    "age": 25,
    "eyeColor": "green",
    "name": "Mckenzie Mejia",
    "gender": "male",
    "company": "MOBILDATA",
    "email": "mckenziemejia@mobildata.com",
    "phone": "+1 (821) 442-3633",
    "address": "680 Beverly Road, Newcastle, Alabama, 8975",
    "about": "Aliqua ad nulla veniam laborum in sit duis quis est duis proident. Sint duis et nostrud aliqua ad ut incididunt consequat. Mollit cupidatat sint ullamco cupidatat duis. In exercitation commodo anim pariatur ea do labore. Est tempor cillum sunt non nisi nisi minim eu quis culpa excepteur aute nisi esse. Ad nostrud amet cupidatat labore consequat incididunt sunt.\r\n",
    "registered": "2014-09-06T10:43:56 -10:00",
    "latitude": 1.901531,
    "longitude": 151.358651,
    "tags": [
      "non",
      "velit",
      "dolore",
      "ut",
      "veniam",
      "cupidatat",
      "nulla"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Vazquez Wilcox"
      },
      {
        "id": 1,
        "name": "Holly Howard"
      },
      {
        "id": 2,
        "name": "Lina Morrison"
      }
    ],
    "greeting": "Hello, Mckenzie Mejia! You have 1 unread messages.",
    "favoriteFruit": "banana"
  }
);

db.person.insert(
  {
    "_id": "57f6f57a495229dde0dd220a",
    "index": 4,
    "guid": "7e39f3f7-ff37-4f50-8b89-3e2a4a95e030",
    "isActive": false,
    "balance": 2019.67,
    "picture": "http://placehold.it/32x32",
    "age": 37,
    "eyeColor": "blue",
    "name": "Marilyn Watson",
    "gender": "female",
    "company": "MOBILDATA",
    "email": "marilynwatson@mobildata.com",
    "phone": "+1 (959) 554-3312",
    "address": "213 Story Street, Bendon, Missouri, 7317",
    "about": "Voluptate non commodo nulla amet cillum amet amet nisi. Laboris esse eu dolore id sint. Non deserunt consequat Lorem eiusmod tempor in ullamco tempor consequat cillum irure non nisi sunt. Id reprehenderit sint qui irure est cupidatat labore officia velit officia. Mollit eu id culpa id commodo. Est duis enim dolor qui amet ad officia mollit qui nulla laboris aliqua dolore nulla. Fugiat cillum ea commodo nisi ipsum exercitation.\r\n",
    "registered": "2015-09-04T04:01:36 -10:00",
    "latitude": 62.972596,
    "longitude": -107.750834,
    "tags": [
      "ipsum",
      "proident",
      "nostrud",
      "nisi",
      "reprehenderit",
      "dolor",
      "veniam"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Florine Jackson"
      },
      {
        "id": 1,
        "name": "Pugh Rowe"
      },
      {
        "id": 2,
        "name": "Courtney Singleton"
      }
    ],
    "greeting": "Hello, Marilyn Watson! You have 5 unread messages.",
    "favoriteFruit": "banana"
  }
);

db.person.insert(
  {
    "_id": "57f6f57acdf968d14702751a",
    "index": 5,
    "guid": "1900ef88-7f10-406a-b1f9-76b9a7de32ba",
    "isActive": false,
    "balance": 2413.73,
    "picture": "http://placehold.it/32x32",
    "age": 24,
    "eyeColor": "green",
    "name": "Leonor Gray",
    "gender": "female",
    "company": "MOBILDATA",
    "email": "leonorgray@mobildata.com",
    "phone": "+1 (946) 600-2387",
    "address": "396 Arkansas Drive, Ryderwood, Tennessee, 5829",
    "about": "Aliquip duis veniam eiusmod enim esse culpa voluptate deserunt fugiat veniam ea voluptate ad. Ex sunt veniam elit occaecat do voluptate nisi. Nisi quis elit dolore elit occaecat adipisicing cillum non sunt veniam labore. Quis exercitation deserunt sint aliquip do do. Do non occaecat voluptate proident incididunt proident ut fugiat quis excepteur exercitation ut fugiat laboris. Qui proident labore aute dolore consequat irure nulla duis officia dolor aute adipisicing.\r\n",
    "registered": "2016-07-09T11:34:51 -10:00",
    "latitude": 85.538973,
    "longitude": 79.656546,
    "tags": [
      "qui",
      "consequat",
      "ex",
      "Lorem",
      "officia",
      "non",
      "tempor"
    ],
    "friends": [
      {
        "id": 0,
        "name": "Walls Farmer"
      },
      {
        "id": 1,
        "name": "Pearson Price"
      },
      {
        "id": 2,
        "name": "Luna Evans"
      }
    ],
    "greeting": "Hello, Leonor Gray! You have 3 unread messages.",
    "favoriteFruit": "banana"
  }
);
